from django.urls import path
from .views import home, add_to_cart, view_cart

urlpatterns = [
    path('', home, name='home'),
    path('cart/', view_cart, name='cart'),
    path('add-to-cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
]